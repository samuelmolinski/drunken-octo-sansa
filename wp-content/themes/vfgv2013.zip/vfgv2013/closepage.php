<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Vestibular FGV</title>

<meta property="fb:app_id" content="440982045925181">
<meta property="fb:admins" content="100000220196116,1049257200,679573088"/>

<script type="text/javascript">
setTimeout( function() {window.close()}, 4500);
</script> 
</head>
<body>
Desafio FGV compartilhado com sucesso em sua timeline. Obrigado.
</body>
</html>
