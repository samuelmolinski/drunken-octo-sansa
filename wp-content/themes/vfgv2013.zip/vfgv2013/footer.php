		</div>
		</div> <!-- end #container -->
		<div class="clearfix"></div>
		<?php wp_footer(); // js scripts are inserted using this function ?>

	</body>

</html>
