<?php

$custom_radio_mb = new WPAlchemy_MetaBox(array
(
	'id' => '_custom_radio_meta',
	'title' => 'Radio Inputs',
	'template' => get_stylesheet_directory() . '/metaboxes/radio-meta.php',
));

/* eof */