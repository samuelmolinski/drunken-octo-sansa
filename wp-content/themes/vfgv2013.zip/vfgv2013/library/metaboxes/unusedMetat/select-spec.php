<?php

$custom_select_mb = new WPAlchemy_MetaBox(array
(
	'id' => '_custom_select_meta',
	'title' => 'Select Inputs',
	'template' => get_stylesheet_directory() . '/metaboxes/select-meta.php',
));

/* eof */